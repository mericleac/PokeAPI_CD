import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http"

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  constructor(private _http: HttpClient) {
    this.getPokemon();
  }
  getPokemon() {
    let squirtle = this._http.get("https://pokeapi.co/api/v2/pokemon/7/");
    console.log("Getting PokeData")
    squirtle.subscribe(data => {
      console.log("SQUIRTLE", data.abilities)
      let message = "Squirtle has the abilities "
      for (let i = 0; i < data.abilities.length; i++) {
        if (i < data.abilities.length - 1) {
          message += `${data.abilities[i].ability.name} and `;
        }
        else {
          message += data.abilities[i].ability.name
        }
      }
      console.log(message);
    })
    let sharedAbility = this._http.get("https://pokeapi.co/api/v2/ability/44/");
    sharedAbility.subscribe(data => {
      console.log("Rain-dish", data)
      console.log(`${data.pokemon.length} Pokemon have the rain-dish ability.`)
      console.log("Pokemon that have the rain-dish ability: ")
      for (let i = 0; i < data.pokemon.length; i++) {
        console.log(data.pokemon[i].pokemon.name)
      }
    })
  }
}

